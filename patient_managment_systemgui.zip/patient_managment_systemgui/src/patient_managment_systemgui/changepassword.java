package patient_managment_systemgui;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class changepassword implements ActionListener{
	JFrame frame = new JFrame();
	Font font=new Font("Arial",Font.BOLD,18); 
	JLabel title;
    JLabel user_name;
    JTextField userfield;
    JLabel pass_word;
    JPasswordField passfield;
    JLabel oldpassword;
    JPasswordField oldpass;
    
  
    JLabel conpass_word;
    JPasswordField conpassfield;
    JButton changepass;
    JButton close;
    public void Login_form()
    {
    	
    	title=new JLabel("CHANGE PASSWORD");
    	user_name=new JLabel("Username:");
    
    	userfield=new JTextField(22);
        oldpassword=new JLabel("Old password");
        oldpass=new JPasswordField(22);
    	pass_word=new JLabel("New Password:");
    	
    	passfield=new JPasswordField(22);
    	conpass_word=new JLabel("Confirm Password:");
    	changepass=new JButton("Change Password");
    	conpassfield=new JPasswordField(22);
    	close=new JButton("close");
    	
    JPanel form_container = new JPanel();
    form_container.setLayout(new GridBagLayout());
	GridBagConstraints c=new GridBagConstraints();
	Font dFont=new Font("Arial",Font.BOLD,30);
    c.insets=new Insets(20,20,20,20);
    
    c.gridx=1;
    c.gridy=0;
   
    title.setFont(dFont);
    title.setForeground(Color.green);
    form_container.add(title,c);

    
    c.gridx=0;
    c.gridy=1;
    user_name.setFont(font);
    user_name.setForeground(Color.green);
    form_container.add(user_name,c);
  
    c.gridx=1;
    c.gridy=1;
    c.ipady=10;
   
    userfield.setBorder(BorderFactory.createLineBorder(Color.green, 2));
    form_container.add(userfield,c);
    c.gridx=0;
    c.gridy=2;
    oldpassword.setFont(font);
    oldpassword.setForeground(Color.green);
    form_container.add(oldpassword,c);
    
    c.gridx=1;
    c.gridy=2;
    c.ipady=10;
    oldpass.setBorder(BorderFactory.createLineBorder(Color.green, 2));
    form_container.add(oldpass,c);
    c.gridx=0;
    c.gridy=3;
    pass_word.setFont(font);
    pass_word.setForeground(Color.green);
    form_container.add(pass_word,c);
    
    c.gridx=1;
    c.gridy=3;
    c.ipady=10;
    passfield.setBorder(BorderFactory.createLineBorder(Color.green, 2));
    form_container.add(passfield,c);
    c.gridx=0;
    c.gridy=4;
    
    conpass_word.setFont(font);
    conpass_word.setForeground(Color.green);
    form_container.add(conpass_word,c);
    
    c.gridx=1;
    c.gridy=4;
    c.ipady=10;
    conpassfield.setBorder(BorderFactory.createLineBorder(Color.green, 2));
    form_container.add(conpassfield,c);
    
    c.gridx=1;
    c.gridy=5;
  c.ipadx=40;
    changepass.setFont(font);
    changepass.setForeground(Color.black);
    changepass.setBackground(Color.green);
    form_container.add(changepass,c);
    c.gridx=1;
    c.gridy=6;

    close.setFont(font);
    close.setForeground(Color.black);
    close.setBackground(Color.green);
    form_container.add(close,c);
	
    
			
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.setSize(750,750);
			frame.setTitle("Change password");
			frame.setVisible(true);	
			frame.setContentPane(form_container);   
		    frame.getContentPane().setBackground(Color.black);
		    changepass.addActionListener(this);
		    close.addActionListener(this);
		
		   
}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==changepass)
		{
		String id=null;
		if(userfield.getText().equals("")||pass_word.getText().equals(""))
		{
			JOptionPane.showMessageDialog(null, "Please Enter Credentials!!!!");
		}
		else {
		try {
			
   			    Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
   			    String path="patient.accdb";
   				String url="jdbc:ucanaccess://"+path;
   				Connection connection=DriverManager.getConnection(url); 
   				Statement p=connection.createStatement();
   			    String sql1 = "select * from form_details where username='"+userfield.getText()+"'and password='"+oldpass.getText()+"'";
   			   ResultSet resultSet=p.executeQuery(sql1);
   			   if(resultSet.next()==true&&passfield.getText().equals(conpassfield.getText()))
   			   {
   			
           String sql="UPDATE form_details SET password=? WHERE username=?";
			   
           PreparedStatement ps=connection.prepareStatement(sql);
           ps.setString(1,passfield.getText());
           ps.setString(2,userfield.getText());
      
           
		   ps.executeUpdate();
		   JOptionPane.showMessageDialog(null, "Password updated sucessFully.");
		   userfield.setText("");
			   passfield.setText("");
			   oldpass.setText("");
			   conpassfield.setText("");
		   connection.close();
   			  }
   			   else 
   			   {
   				   JOptionPane.showMessageDialog(null, "Wrong username and password cant abble to update password.");
   				   userfield.setText("");
   				   passfield.setText("");
   				   oldpass.setText("");
   				   conpassfield.setText("");
   			   }
		
		} catch (Exception e2) {
			// TODO: handle exception
		}
		}
	
		}
		else {
			frame.dispose();
		}
		}
	}

