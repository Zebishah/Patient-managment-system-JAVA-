package patient_managment_systemgui;

public class Patientmanagmentsys
{
public static void main(String[]args)
{
startinginterface s=new startinginterface();
s.Startinginterface();
}
}
