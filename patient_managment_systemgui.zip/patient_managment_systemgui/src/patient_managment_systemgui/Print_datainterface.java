package patient_managment_systemgui;

import java.awt.Color;
import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.print.Doc;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Print_datainterface implements ActionListener{
	JFrame sframe= new JFrame();
	JLabel title=new JLabel("Which Data You Wanna view:");
	JButton doc=new JButton();
	JButton pat=new JButton();
	JButton dis=new JButton();
	JButton closeButton=new JButton("Close");
	public void showdatainterface()
	{
		sframe.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		sframe.setSize(740, 650);
		sframe.setLocation(220,10);
	
		sframe.setResizable(false);
		sframe.setVisible(true);
		Container container=sframe.getContentPane();
		
		doc.setText("View Doctors Data");
		
		pat.setText("View Patient Data");
		
		dis.setText("View Diseases Data");
	

		
		 JPanel form_container = new JPanel();
 	    form_container.setLayout(new GridBagLayout());
 	   sframe.setTitle("Show data interface(zohaib-4122)");
 		GridBagConstraints c=new GridBagConstraints();
 		
 		
 		c.insets=new Insets(20,20,20,20);
 		
 		c.gridx=0;
 	    c.gridy=0;
 	   title.setForeground(Color.green);
 	   form_container.add(title,c);
 	    
	    c.gridx=0;
	    c.gridy=1;
	    c.ipadx=24;
	    c.ipady=14;
	    doc.setForeground(Color.black);
	    doc.setBackground(Color.green);
	    form_container.add(doc,c);
	    
	    c.gridx=0;
	    c.gridy=2;
	    c.ipadx=29;
	    c.ipady=14;
	    pat.setForeground(Color.black);
	    pat.setBackground(Color.green);
		sframe.setTitle("Show data interface(zohaib-4122)");
	    form_container.add(pat,c);
	  
	    c.gridx=0;
	    c.gridy=3;
	    c.ipadx=20;
	    c.ipady=14;
	    dis.setForeground(Color.black);
	    dis.setBackground(Color.green);
	    form_container.add(dis,c);
	    c.gridx=0;
	    c.gridy=4;
	    c.ipadx=20;
	    c.ipady=14;
	    closeButton.setForeground(Color.black);
	    closeButton.setBackground(Color.green);
	    form_container.add(closeButton,c);
	    sframe.setContentPane(form_container);
		sframe.getContentPane().setBackground(Color.black);
		doc.addActionListener(this);
		pat.addActionListener(this);
		dis.addActionListener(this);
		closeButton.addActionListener(this);
	}
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource()==doc)
		{
			Viewdoctors_detail s=new Viewdoctors_detail();
			s.showdetails();
		}
		else if(e.getSource()==pat)
		{
			ViewPatientdetails s=new ViewPatientdetails();
			s.showdetails();
		}
		else if(e.getSource()==dis)
		{
			Viewdiseases_details s=new Viewdiseases_details();
			s.showdetails();
		}
		else if(e.getSource()==closeButton)
		{
			sframe.dispose();
		}
		
     

	}
}
