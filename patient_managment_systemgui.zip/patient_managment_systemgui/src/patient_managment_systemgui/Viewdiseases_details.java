package patient_managment_systemgui;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

public class Viewdiseases_details implements ActionListener{
	JFrame frame = new JFrame();
	JLabel idJLabel;
	JTable table;
	JButton viewButton=new JButton("Show data");
	JButton closeButton=new JButton("Close");
public void showdetails()
{
	Object[][]rows= {};
	String []col= {"Disease_Id","DiseaseName","DiseaseDescription"};
	idJLabel=new JLabel("Diseases Details:");
	DefaultTableModel d=new DefaultTableModel(rows,col);
	table=new JTable(d);
	
	   JPanel form_container = new JPanel();
	  

	 
	    form_container.setLayout(new GridBagLayout());
	   
		GridBagConstraints c=new GridBagConstraints();
		 JScrollPane sePane=new JScrollPane(table);
			
		    c.gridx=0;
		    c.gridy=0;
		    idJLabel.setForeground(Color.green);
		    form_container.add(idJLabel,c);
		    JTableHeader tableHeader=table.getTableHeader();
			tableHeader.setForeground(Color.black);
			tableHeader.setBackground(Color.green);
			sePane.setBackground(Color.green);
			table.setBackground(Color.green);
			table.setOpaque(false);
		    c.insets = new Insets(20, 20, 20, 20);
			 
		    c.gridx=0;
		    c.gridy=2;
		    c.ipadx=700;
		    c.ipady=200;
		  
			sePane.setBorder(BorderFactory.createLineBorder(Color.green, 2));
		    form_container.add(sePane,c);
		    c.gridx=0;
    	    c.gridy=4;
    	    c.ipadx=19;
    	    c.ipady=10;
    	    viewButton.setForeground(Color.black);
		    viewButton.setBackground(Color.green);
    	    form_container.add(viewButton,c);
    	    c.gridx=0;
    	    c.gridy=5;
    	    c.ipadx=19;
    	    c.ipady=10;
    	    closeButton.setForeground(Color.black);
		    closeButton.setBackground(Color.green);
    	    form_container.add(closeButton,c);
    	    
    	    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    		frame.setSize(1370,770);
    		frame.setContentPane(form_container);
    		frame.getContentPane().setBackground(Color.black);
    		frame.setTitle("View doctors details");
    		frame.setVisible(true);	
    		
            viewButton.addActionListener(this);
            closeButton.addActionListener(this);
}
public void actionPerformed(ActionEvent e) {
	// TODO Auto-generated method stub
	if(e.getSource()==viewButton)
	{
		 
	try {
	Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
    String path="patient.accdb";
	String url="jdbc:ucanaccess://"+path;
	Connection connection=DriverManager.getConnection(url);
	
	  String sql1="SELECT * FROM Diseases ";
	   PreparedStatement p1=connection.prepareStatement(sql1);
	   ResultSet r=p1.executeQuery();
	   
	table.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(r));
	   

    } catch (Exception e1) {
    	// TODO: handle exception
    }
	
		
	}
	else if(e.getSource()==closeButton)
	{
		frame.dispose();
	}
}
}
