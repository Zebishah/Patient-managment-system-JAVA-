package patient_managment_systemgui;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.security.interfaces.RSAKey;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Adddoctor implements ActionListener
{
	JFrame frame = new JFrame();
	JLabel title=new JLabel("Add doctor details");
	JLabel doctorname=new JLabel("Doctor Name:");
	JLabel specilize=new JLabel("Specialist Of:");
	JComboBox<String> selectdis= new JComboBox<String>();
	JButton AddButton=new JButton("Add");
	JButton closeButton=new JButton("Close");
    JTextField docfield=new JTextField(25);
    JTextField dis=new JTextField(25);
    public void Add_doctor()
    {
    	
    	Font f=new Font("Arial",Font.BOLD,20);
      	Font fa=new Font("Arial",Font.BOLD,30);
    	doctorname.setFont(f);
    	title.setFont(fa);
    	AddButton.setFont(f);   
    	closeButton.setFont(f);
    	specilize.setFont(f);
    	   JPanel form_container = new JPanel();
    	    form_container.setLayout(new GridBagLayout());
    		GridBagConstraints c=new GridBagConstraints();
    	    c.insets=new Insets(20,20,20,20);
    	    c.gridx=1;
    	    c.gridy=0;
    	    title.setForeground(Color.green);
    	    form_container.add(title,c);
    	    
    	    c.gridx=0;
    	    c.gridy=1;
    	    doctorname.setForeground(Color.green);
    	    form_container.add(doctorname,c);
    	  
    	    c.gridx=1;
    	    c.gridy=1;
    	    c.ipady=14;
    	    docfield.setBorder(BorderFactory.createLineBorder(Color.green, 2));;
    	    form_container.add(docfield,c);
    	    
    	    c.gridx=0;
    	    c.gridy=2;
    	    specilize.setForeground(Color.green);
    	    frame.setTitle("Add doctor record-(zohaib-4122)");
    	    form_container.add(specilize,c);
    try {
    	Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
        String path="patient.accdb";
    	String url="jdbc:ucanaccess://"+path;
    	Connection connection=DriverManager.getConnection(url);
    	 Statement ps=connection.createStatement();
    	 String sql="select DiseaseName from Diseases";
    	 frame.setTitle("Add doctor record-(zohaib-4122)");
    	  ResultSet resultSet=ps.executeQuery(sql);
    	  while(resultSet.next()==true)
    	  {
    		  String disname=resultSet.getString("DiseaseName");
    		  selectdis.addItem(disname);
    	  }
	} catch (Exception e) {
		// TODO: handle exception
	}
    	    
    	    c.gridx=1;
    	    c.gridy=2;
    	    c.ipadx=59;
    	    c.ipady=20;
    	    selectdis.setBorder(BorderFactory.createLineBorder(Color.green, 2));;
    	    form_container.add(selectdis,c);

    	    c.insets=new Insets(70,0,0,0);
    	    c.gridx=0;
    	    c.gridy=6;
    	    c.ipadx=19;
    	    c.ipady=10;
    	    AddButton.setForeground(Color.black);
    	    AddButton.setBackground(Color.green);
    	    form_container.add(AddButton,c);
    	    
    	    c.gridx=1;
    	    c.gridy=6;
    	    c.ipadx=19;
    	    c.ipady=10;
    	    closeButton.setForeground(Color.black);
    	    closeButton.setBackground(Color.green);
    	    form_container.add(closeButton,c);


    		form_container.setBounds(50, 150, 600, 300);
    		
    	    
    				
    				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    				
    				frame.setSize(750,750);
    				frame.setVisible(true);	
    				
    				 frame.setContentPane(form_container);
    					frame.getContentPane().setBackground(Color.black);
    			   
    			    AddButton.addActionListener(this);
    			    closeButton.addActionListener(this);
    			   
    }
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==AddButton)
		{
			
		try {
			String Doctor_ID=null;
		Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
	    String path="patient.accdb";
		String url="jdbc:ucanaccess://"+path;
		Connection connection=DriverManager.getConnection(url);
		   
		   String sql1="select * from Diseases where DiseaseName=?";
		   PreparedStatement ps=connection.prepareStatement(sql1);
		  String select=(String) selectdis.getSelectedItem();
		   ps.setString(1,select);
		   ResultSet rs=ps.executeQuery();
		   String id=null;
		   if(rs.next())
		   {
			    id=rs.getString("Disease_Id");
		   }
		   dis.setText(id);
           String sql="INSERT INTO Doctors(Doctor_ID,Doctor_Name,Disease_ID) VALUES(?,?,?)";
           PreparedStatement s=connection.prepareStatement(sql);
			    s.setString(1,Doctor_ID);
			    s.setString(2,docfield.getText());
			    s.setString(3,dis.getText());
				s.executeUpdate();
			    JOptionPane.showMessageDialog(null, "Data added sucessFully.");
			    docfield.setText("");
				dis.setText("");
		   connection.close();
		} catch (Exception e2) {
			// TODO: handle exception
		}
			}
	
		else if(e.getSource()==closeButton)
			{
			frame.dispose();
		}
	}
    
}
