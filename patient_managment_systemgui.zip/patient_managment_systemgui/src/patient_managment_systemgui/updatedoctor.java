package patient_managment_systemgui;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;

public class updatedoctor implements ActionListener{
	JFrame frame = new JFrame();
	JLabel title=new JLabel("Update doctor details");
	JLabel doctorname=new JLabel("Doctor Name:");
	JLabel specilize=new JLabel("Specialist Of:");
	JComboBox<String> selectdis;
	JButton AddButton=new JButton("Add");
	JButton closeButton=new JButton("Close");
    JTextField docfield=new JTextField(25);
    JTextField dis=new JTextField(25);
    JLabel idJLabel;
	JComboBox<String> ids;
    public void update_doctor()
    {
    	
    	Font f=new Font("Arial",Font.BOLD,20);
    	doctorname.setFont(f);
    	title.setFont(f);
    	AddButton.setFont(f);   
    	closeButton.setFont(f);
    	specilize.setFont(f);
    	idJLabel=new JLabel("Select Doctor Id :");
    	selectdis= new JComboBox<String>();
		ids=new JComboBox<String>();
		   try {
		    	Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
		     String path="patient.accdb";
		    	String url="jdbc:ucanaccess://"+path;
		    	Connection connection=DriverManager.getConnection(url);
		    	 Statement ps=connection.createStatement();
		    	 String sql3="select Doctor_ID from Doctors";
		    	  ResultSet resultSet=ps.executeQuery(sql3);
		    	  while(resultSet.next()==true)
		    	  {
		    		  String disname=resultSet.getString("Doctor_ID");
		    		  ids.addItem(disname);
		    	  }
		    
		    	  connection.close();
		    } catch (Exception e) {
		    	e.printStackTrace();
		    }
		    	   
		    	   
		
	
		 
		    JPanel sePane=new JPanel();
		    sePane.add(ids);
    	    JPanel form_container = new JPanel();
    	    form_container.setLayout(new GridBagLayout());
    		GridBagConstraints c=new GridBagConstraints();
    	    c.insets=new Insets(20,20,20,20);
    	 
    		c.gridx=0;
 		    c.gridy=0;
 		    idJLabel.setFont(f);
 		    idJLabel.setForeground(Color.green);
 		    form_container.add(idJLabel);
 		 
 		    c.gridx=1;
 		    c.gridy=0;
 		 
 		    sePane.setBorder(BorderFactory.createLineBorder(Color.green, 2));
 		    form_container.add(sePane,c);
    	    
    	    c.gridx=0;
    	    c.gridy=1;
    	    doctorname.setForeground(Color.green);
    	    form_container.add(doctorname,c);
    	  
    	    c.gridx=1;
    	    c.gridy=1;
    	    c.ipady=14;
    	    docfield.setBorder(BorderFactory.createLineBorder(Color.green, 2));
    	    form_container.add(docfield,c);
    	    
    	    c.gridx=0;
    	    c.gridy=2;
    	    specilize.setForeground(Color.green);
    	    form_container.add(specilize,c);
    try {
    	Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
        String path="patient.accdb";
    	String url="jdbc:ucanaccess://"+path;
    	Connection connection=DriverManager.getConnection(url);
    	 Statement ps=connection.createStatement();
    	 String sql2="select DiseaseName from Diseases";
    	  ResultSet resultSet=ps.executeQuery(sql2);
    	  while(resultSet.next()==true)
    	  {
    		  String disname=resultSet.getString("DiseaseName");
    		  selectdis.addItem(disname);
    	  }
	} catch (Exception e) {
		// TODO: handle exception
	}
    	    
    	    c.gridx=1;
    	    c.gridy=2;
    	    c.ipadx=59;
    	    c.ipady=20;
    	    selectdis.setBorder(BorderFactory.createLineBorder(Color.green, 2));
    	    form_container.add(selectdis,c);
    	    c.insets=new Insets(70,0,0,0);
    	    c.gridx=0;
    	    c.gridy=3;
    	    c.ipadx=49;
    	    c.ipady=10;
    	    AddButton.setForeground(Color.black);
		    AddButton.setBackground(Color.green);
    	    form_container.add(AddButton,c);
    	    
    	    c.gridx=1;
    	    c.gridy=3;
    	    c.ipadx=19;
    	    c.ipady=10;
    	    closeButton.setForeground(Color.black);
		    closeButton.setBackground(Color.green);
    	    form_container.add(closeButton,c);


    		form_container.setBounds(50, 150, 600, 300);
    		
    	    
    				
    				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    				
    				frame.setSize(750,750);
    				frame.setVisible(true);	
    				frame.setTitle("Update doctor record");
    				frame.setContentPane(form_container);
    				frame.getContentPane().setBackground(Color.black);
    			    selectdis.addActionListener(this);
    			    AddButton.addActionListener(this);
    			    closeButton.addActionListener(this);
    			 
    }
	@Override
	       public void actionPerformed(ActionEvent e) {
		    String selected=(String)ids.getSelectedItem();
		    
		     if(e.getSource()==AddButton)
			{
			String id=null;
			if(docfield.getText().equals(""))
			{
				JOptionPane.showMessageDialog(null, "Please Enter Credentials!!!!");
			}
			else {
			try {
				
	   			    Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
	   			    String path="patient.accdb";
	   				String url="jdbc:ucanaccess://"+path;
	   				Connection connection=DriverManager.getConnection(url);
	   				   
	   				   String sql1="select * from Diseases where DiseaseName=?";
	   				   PreparedStatement ps=connection.prepareStatement(sql1);
	   				  String select=(String) selectdis.getSelectedItem();
	   				   ps.setString(1,select);
	   				   ResultSet rs=ps.executeQuery();
	   				 
	   				   if(rs.next())
	   				   {
	   					    id=rs.getString("Disease_Id");
	   				   }
	   				 
	   			 dis.setText(id);
	
			
	           String sql="UPDATE Doctors SET Doctor_Name=?,Disease_ID=? WHERE Doctor_ID=?";
				   
	           PreparedStatement p=connection.prepareStatement(sql);
	         p.setString(1,docfield.getText());
	         p.setString(2,dis.getText());
	         p.setString(3, selected);
			   p.executeUpdate();
			   JOptionPane.showMessageDialog(null, "Data updated sucessFully.");
			docfield.setText("");
			dis.setText("");
			   connection.close();
			} catch (Exception e2) {
				// TODO: handle exception
			}
			}
		}
		else if(e.getSource()==closeButton)
		{
			frame.dispose();
		}
	}
}
