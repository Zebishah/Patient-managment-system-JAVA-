package patient_managment_systemgui;

import java.awt.Color;
import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

public class Searchdoc_bydis implements ActionListener{

	JFrame frame = new JFrame();
	Container container=frame.getContentPane();
	JLabel idJLabel;
	JTable table;
	
	JButton SearchButton=new JButton("Search");
	JButton CloseButton=new JButton("Close");
	JTextField ids;
	DefaultListModel<String> model = new DefaultListModel<String>();
	public void search_doctor()
	{
		Object[][]rows= {};
		String []col= {"Doctor_ID","Doctor_Name","Disease_specialized"};
		
		idJLabel=new JLabel("Enter Doctor Disease specialization:");
		ids=new JTextField();
		
		DefaultTableModel d=new DefaultTableModel(rows,col);
		table=new JTable(d);
	
	
		 JPanel form_container = new JPanel();
		
		 
		    form_container.setLayout(new GridBagLayout());
		   
			GridBagConstraints c=new GridBagConstraints();

		    ids.setBorder(BorderFactory.createLineBorder(Color.black, 2));

		    JScrollPane sePane=new JScrollPane(table);
	
		    c.gridx=0;
		    c.gridy=0;
		    idJLabel.setForeground(Color.green);
		    form_container.add(idJLabel,c);
		    c.gridx=0;
		    c.gridy=1;
		    c.ipadx=200;
		    c.ipady=10;
		    ids.setBorder(BorderFactory.createLineBorder(Color.green, 2));
		    form_container.add(ids,c);
			JTableHeader tableHeader=table.getTableHeader();
			tableHeader.setForeground(Color.black);
			tableHeader.setBackground(Color.green);
			sePane.setBackground(Color.green);
			table.setBackground(Color.green);
			table.setOpaque(false);
			c.insets = new Insets(20, 20, 20, 20);
		    c.gridx=0;
		    c.gridy=2;
		    c.ipadx=900;
		    c.ipady=200;
		    sePane.setBorder(BorderFactory.createLineBorder(Color.green, 2));
		    form_container.add(sePane,c);
		    c.gridx=0;
    	    c.gridy=4;
    	    c.ipadx=49;
    	    c.ipady=10;
    	    SearchButton.setForeground(Color.black);
		    SearchButton.setBackground(Color.green);
    	    form_container.add(SearchButton,c);
    	    c.gridx=0;
    	    c.gridy=5;
    	    c.ipadx=19;
    	    c.ipady=10;
    	    CloseButton.setForeground(Color.black);
		    CloseButton.setBackground(Color.green);
		    
    	    form_container.add(CloseButton,c);
    	    
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(1370,770);
		frame.setTitle("Search Doctor by disease");
		frame.setContentPane(form_container);
		frame.getContentPane().setBackground(Color.black);
		frame.setVisible(true);	
		
        SearchButton.addActionListener(this);
        CloseButton.addActionListener(this);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==SearchButton)
		{
			if(ids.getText().equals(""))
			{
				JOptionPane.showMessageDialog(null, "Please Enter Credentials!!!!");
			}
			else {
		 
	
		try {
		Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
	    String path="patient.accdb";
		String url="jdbc:ucanaccess://"+path;
		Connection connection=DriverManager.getConnection(url);
		Statement p=connection.createStatement();
		  String sql2="select * from Diseases where DiseaseName='"+ids.getText()+"'";
		  
		 
		
		   ResultSet rs=p.executeQuery(sql2);
		   int id=0;
		   if(rs.next()==true)
		   {
			    id=rs.getInt("Disease_Id");
		   }
		 String sql3 = "select * from Diseases where DiseaseName='"+ids.getText()+"'";
		 String sq="SELECT * FROM Doctors WHERE Disease_ID='"+id+"'";
		   ResultSet resultSet=p.executeQuery(sql3);
		   ResultSet resultSets=p.executeQuery(sq);
		   if(resultSet.next()==true&&resultSets.next()==true)
		   {
		   
		  String sql="select * from Diseases where DiseaseName=?";
		   PreparedStatement ps=connection.prepareStatement(sql);
		  String select=(String)ids.getText();
		   ps.setString(1,select);
		   ResultSet rsa=ps.executeQuery();
		   String ids=null;
		   if(rsa.next())
		   {
			    ids=rsa.getString("Disease_Id");
		   }
		  String sql1="SELECT * FROM Doctors WHERE Disease_ID='"+ids+"'";
		   PreparedStatement pe=connection.prepareStatement(sql1);
		   ResultSet r=pe.executeQuery();
		   
		table.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(r));
		   }
		   else {
			   JOptionPane.showMessageDialog(null, "Data not exsisted.");
			   ids.setText("");
		}
	    } catch (Exception e1) {
	    	// TODO: handle exception
	    }
			}
		}
		else if(e.getSource()==CloseButton)
		{
			frame.dispose();
		}
	}
}
