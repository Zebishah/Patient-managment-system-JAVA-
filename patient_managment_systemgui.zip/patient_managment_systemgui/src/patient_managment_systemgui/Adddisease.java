package patient_managment_systemgui;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Adddisease implements ActionListener{

	JFrame frame = new JFrame();
	JLabel diseasename=new JLabel("Disease Name:");

    
    JTextField disfield=new JTextField(25);
    
    JLabel diseasedescription=new JLabel("Disease discription:");
   
   
    JTextField desfield=new JTextField(25);
  
    JButton AddButton=new JButton("Add");
    JButton closeButton=new JButton("Close");
public void Add_disease()
{

			// JPanel = a GUI component that functions as a container to hold other components
		JLabel title=new JLabel("Add disease");
		Font f=new Font("Arial",Font.BOLD,20);
		Font fa=new Font("Arial",Font.BOLD,30);
	title.setFont(fa);
		
	JPanel titlecontainer = new JPanel();

	titlecontainer.setBounds(280, 100, 150, 40);
	titlecontainer.setLayout(new FlowLayout(FlowLayout.CENTER));
	titlecontainer.add(title);
	//credentials
	
    diseasename.setFont(f);

    diseasedescription.setFont(f);
   
    
    AddButton.setFont(f);
    
   
    closeButton.setFont(f);
    //end
	
    JPanel form_container = new JPanel();
    form_container.setLayout(new GridBagLayout());
	GridBagConstraints c=new GridBagConstraints();
    c.insets=new Insets(20,20,20,20);
    c.gridx=1;
    c.gridy=0;
    title.setForeground(Color.green);
    form_container.add(title,c);
    c.gridx=0;
    c.gridy=1;
    diseasename.setForeground(Color.green);
    form_container.add(diseasename,c);
  
    c.gridx=1;
    c.gridy=1;
    c.ipady=14;
    disfield.setBorder(BorderFactory.createLineBorder(Color.green, 2));;
    form_container.add(disfield,c);
    
    c.gridx=0;
    c.gridy=2;
    diseasedescription.setForeground(Color.green);
    form_container.add(diseasedescription,c);
    
    c.gridx=1;
    c.gridy=2;
    desfield.setBorder(BorderFactory.createLineBorder(Color.green, 2));;
    form_container.add(desfield,c);
   
    c.gridx=0;
    c.gridy=5;
  
    AddButton.setForeground(Color.black);
    AddButton.setBackground(Color.green);
    form_container.add(closeButton,c);
    
    c.gridx=1;
    c.gridy=5;
    
    closeButton.setForeground(Color.black);
    closeButton.setBackground(Color.green);
    form_container.add(AddButton,c);


	form_container.setBounds(50, 150, 600, 300);
	
    
			
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.setLocation(220,10);
			frame.setSize(750,750);
			frame.setResizable(false);
			frame.setVisible(true);	
			frame.setTitle("Add disease record");
			  frame.setContentPane(form_container);
				frame.getContentPane().setBackground(Color.black);
		    AddButton.addActionListener(this);
		    closeButton.addActionListener(this);
		
		   
		    
		

}
@Override
public void actionPerformed(ActionEvent e) {
	// TODO Auto-generated method stub
	if(e.getSource()==AddButton)
	{
	
		if(disfield.getText().equals("")||desfield.getText().equals(""))
		{
			JOptionPane.showMessageDialog(null, "Please Enter Credentials");
		}
		else {
			
			try {
		int Disease_Id = 0;
	Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
    String path="patient.accdb";
	String url="jdbc:ucanaccess://"+path;
	Connection connection=DriverManager.getConnection(url);
	Statement p=connection.createStatement();
	   String sql1 = "select * from Diseases where DiseaseName='"+disfield.getText()+"' and DiseaseDescription='"+desfield.getText()+"'";
	  
	   ResultSet resultSet=p.executeQuery(sql1);
	   if(resultSet.next()==true)
	   {
		   JOptionPane.showMessageDialog(null, "Data Already exsisted.");
	       disfield.setText("");
	       desfield.setText("");

	   }
	   else {
		   String sql="insert into Diseases values('"+Disease_Id+"','"+disfield.getText()+"','"+desfield.getText()+"')";
		   
			p.executeUpdate(sql);
			disfield.setText("");
			desfield.setText("");
				JOptionPane.showMessageDialog(null, "Data added sucessFully.");
	}
	   connection.close();
	} catch (Exception e2) {
		// TODO: handle exception
	}
	}
}
	else if(e.getSource()==closeButton)
		{
		frame.dispose();
	}
	
}

}

