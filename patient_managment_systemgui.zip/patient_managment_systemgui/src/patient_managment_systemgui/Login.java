package patient_managment_systemgui;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
public class Login implements ActionListener
{
	JFrame frame = new JFrame();
	JLabel user_name;
	Font f=new Font("Arial",Font.BOLD,23);
	Font f2=new Font("Arial",Font.BOLD,24);
    JTextField userfield;
    JLabel pass_word;
    ImageIcon addp ;
    JPasswordField passfield;
    JLabel label;
    JLabel title;
    JButton loginButton;
    JButton closeButton;
public void Login_form()
{

	user_name=new JLabel("Username:");
	userfield=new JTextField(22);
	pass_word=new JLabel("Password:");
	passfield=new JPasswordField(22);
	loginButton=new JButton("Login");
	closeButton=new JButton("close");
    title=new JLabel("Login-Form:");
	Font f=new Font("Arial",Font.BOLD,20);
	title.setFont(f);
	label=new JLabel();

	addp=new ImageIcon("E://icons8-user-64.png"); 
	JPanel titlecontainer = new JPanel();
    
	titlecontainer.setBounds(280, 100, 150, 40);
	titlecontainer.setLayout(new FlowLayout(FlowLayout.CENTER));
	titlecontainer.add(title);
	
    user_name.setFont(f);
    user_name.setForeground(Color.green);
    pass_word.setFont(f);
    pass_word.setForeground(Color.green);

    
    loginButton.setFont(f);
    //end
	try {
		
	label=new JLabel();

	addp=new ImageIcon("E://icons8-user-64.png"); 
	label.setVerticalTextPosition(JButton.BOTTOM);
	label.setHorizontalTextPosition(JButton.CENTER);
	   
    label.setIcon(addp);
    title.setFont(f2);
    label.setHorizontalTextPosition(JLabel.CENTER);
    label.setVerticalTextPosition(JLabel.BOTTOM);
		} catch (Exception e) {
			// TODO: handle exception
		}
	JPanel sJPanel=new JPanel();
	sJPanel.add(label);
	sJPanel.setPreferredSize(new Dimension(100,100));
    JPanel form_container = new JPanel();
    form_container.setLayout(new GridBagLayout());
	GridBagConstraints c=new GridBagConstraints();
	
    c.insets=new Insets(20,20,20,20);
    c.gridx=0;
    c.gridy=0;
   
   sJPanel.setBackground(Color.green);
   form_container.add(sJPanel,c);
    c.gridx=1;
    c.gridy=0;
   title.setForeground(Color.green);
    form_container.add(title,c);
    c.gridx=0;
    c.gridy=1;
    form_container.add(user_name,c);
  
    c.gridx=1;
    c.gridy=1;
    c.ipady=10;
    userfield.setBorder(BorderFactory.createLineBorder(Color.green, 2));
    form_container.add(userfield,c);
    
    c.gridx=0;
    c.gridy=2;
    form_container.add(pass_word,c);
    
    c.gridx=1;
    c.gridy=2;
    passfield.setBorder(BorderFactory.createLineBorder(Color.green, 2));
    form_container.add(passfield,c);
    
    c.gridx=1;
    c.gridy=5;
    c.ipadx=47;
    loginButton.setForeground(Color.black);
    loginButton.setBackground(Color.green);
    form_container.add(loginButton,c);
    
    c.gridx=1;
    c.gridy=6;
    c.ipadx=17;
    closeButton.setForeground(Color.black);
    closeButton.setBackground(Color.green);
    form_container.add(closeButton,c);

	form_container.setBounds(50, 150, 600, 300);
	
    
			
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.setLocation(220,10);
			frame.setTitle("Login-Form");
			frame.setSize(750,750);
			frame.setResizable(false);
			frame.setVisible(true);	
		    frame.add(titlecontainer);
		    frame.setContentPane(form_container);  
			frame.getContentPane().setBackground(Color.black);
		    loginButton.addActionListener(this);
		    closeButton.addActionListener(this);
		
		   
		    
		

}
@Override
public void actionPerformed(ActionEvent e) {
	if(e.getSource()==loginButton)
	{
	// TODO Auto-generated method stub
	if(userfield.getText().equals("")||pass_word.getText().equals(""))
	{
		JOptionPane.showMessageDialog(null, "Text Fields cant be empty enter Your credentials for login....");
	}
	else
	{
		
	try {

	Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
    String path="patient.accdb";
	String url="jdbc:ucanaccess://"+path;
	Connection connection=DriverManager.getConnection(url);
	String sql="select * from form_details where username='"+userfield.getText()+"' and password='"+passfield.getText()+"'";
	PreparedStatement ps=connection.prepareStatement(sql);
	ResultSet result=ps.executeQuery();
	if(result.next())
	{
		
		JOptionPane.showMessageDialog(null, "Login sucessFully.");
		userfield.setText("");
		passfield.setText("");
		frame.dispose();
		Administratorgui a=new Administratorgui();
		a.AdminMenu_bar();
		a.Admin_toolbar();
	}
	else {
	
		JOptionPane.showMessageDialog(null, "Login denied.");
		userfield.setText("");
		passfield.setText("");
	}
connection.close();
	} catch (Exception e2) {
		// TODO: handle exception
	}
	}
	
	}
else if(e.getSource()==closeButton){
		frame.dispose();
	}
}

}
