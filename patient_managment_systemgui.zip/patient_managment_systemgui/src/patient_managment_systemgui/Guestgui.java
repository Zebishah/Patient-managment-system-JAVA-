package patient_managment_systemgui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JToolBar;

public class Guestgui implements ActionListener{
	JFrame frame = new JFrame();
	JButton close=new JButton("close");
    JMenuBar menuBar;
    JMenu Searchrecord;
    JMenu Printrec;
    JMenu Help;
    JMenuItem searchpatient_name;
    JMenuItem searchpatient_Id;
    JMenuItem searchpatient_age;
    JMenuItem searchpatient_disease;
    JMenuItem searchpatient_doctor;
    JMenuItem searchdoctor_name;
    JMenuItem searchdoctor_disspec;
    JMenuItem PrintDoc;
    JMenuItem Printpat;
    JMenuItem Printdis;
    JMenuItem Aboutus;
    JMenuItem changepassword;
    
    JToolBar toolBar=new JToolBar();
    ImageIcon SearchP;
    ImageIcon Print;
   
    JButton search;
    JButton print;
   
public void guestMenu_bar()
{

			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.setTitle("Guest Interface");
			frame.setSize(1370,770);
			
			
			
		
			
			Searchrecord=new JMenu("Search record");
			Searchrecord.setForeground(Color.green);
		    Printrec=new JMenu("Print record");
		    Printrec.setForeground(Color.green);
			Help=new JMenu("Help Section");
			Help.setForeground(Color.green);
		
			
			
			    
			     searchpatient_name=new JMenuItem("Search_patientbyname");
			     searchpatient_name.setForeground(Color.green);
			     searchpatient_name.setBackground(Color.black);
			     searchpatient_Id=new JMenuItem("Search_patientbyid");
			     searchpatient_Id.setForeground(Color.green);
			     searchpatient_Id.setBackground(Color.black);
			     searchpatient_age=new JMenuItem("Search_patientbyage");
			     searchpatient_age.setForeground(Color.green);
			     searchpatient_age.setBackground(Color.black);
			     searchpatient_disease=new JMenuItem("Search_patientbydisease");
			     searchpatient_disease.setForeground(Color.green);
			     searchpatient_disease.setBackground(Color.black);
			     searchpatient_doctor=new JMenuItem("Search_patientbydoctor");
			     searchpatient_doctor.setForeground(Color.green);
			     searchpatient_doctor.setBackground(Color.black);
			     searchdoctor_name=new JMenuItem("Search_doctorbyname");
			     searchdoctor_name.setForeground(Color.green);
			     searchdoctor_name.setBackground(Color.black);
			     searchdoctor_disspec=new JMenuItem("Search_doctorbyspec");
			     searchdoctor_disspec.setForeground(Color.green);
			     searchdoctor_disspec.setBackground(Color.black);
			     PrintDoc=new JMenuItem("Print Doctors data");
			     PrintDoc.setForeground(Color.green);
			     PrintDoc.setBackground(Color.black);
			     Printpat=new JMenuItem("Print patients data");
			     Printpat.setForeground(Color.green);
			     Printpat.setBackground(Color.black);
			     Printdis=new JMenuItem("Print Diseases data");
			     Printdis.setForeground(Color.green);
			     Printdis.setBackground(Color.black);
			     Aboutus=new JMenuItem("About us");
			     Aboutus.setForeground(Color.green);
			     Aboutus.setBackground(Color.black);
			     
			     changepassword=new JMenuItem("changepassword");
			     changepassword.setForeground(Color.green);
			     changepassword.setBackground(Color.black);
			 	menuBar=new JMenuBar();
			 	menuBar.setBackground(Color.black);
			 	menuBar.setPreferredSize(new Dimension(100,30));
			 	menuBar.setBorder(BorderFactory.createLineBorder(Color.green, 2));
				frame.setJMenuBar(menuBar);
			     
			     
			     menuBar.add(Searchrecord);
			     menuBar.add(Printrec);
			     menuBar.add(Help);
			     
			     Searchrecord.add(searchpatient_name);
			     Searchrecord.add(searchpatient_Id);
			     Searchrecord.add(searchpatient_age);
			     Searchrecord.add(searchpatient_disease);
			     Searchrecord.add(searchpatient_doctor);
			     Searchrecord.add(searchdoctor_name);
			     Searchrecord.add(searchdoctor_disspec);
			     Printrec.add(PrintDoc);
			     Printrec.add(Printpat);
			     Printrec.add(Printdis);
			     Help.add(Aboutus);
			     Help.add(changepassword);
			     
			     
			     frame.setVisible(true);	
			     JPanel form_container = new JPanel();
			     close.setForeground(Color.black);
			     close.setBackground(Color.green);
                 form_container.setBackground(Color.black);
				 form_container.add(close);
		   
		PrintDoc.addActionListener(this);
		Printdis.addActionListener(this);
		Printpat.addActionListener(this);
	
	
		searchpatient_age.addActionListener(this);
		searchpatient_name.addActionListener(this);
		searchpatient_Id.addActionListener(this);
		searchpatient_disease.addActionListener(this);
		searchpatient_doctor.addActionListener(this);
		searchdoctor_name.addActionListener(this);
		searchdoctor_disspec.addActionListener(this);
		Aboutus.addActionListener(this);
		changepassword.addActionListener(this);
		close.addActionListener(this);
		frame.add(form_container,BorderLayout.PAGE_END);
		frame.getContentPane().setBackground(Color.black);
	
}	
public void title()
{
	JLabel s=new JLabel("WELCOME TO OUR");
	JLabel s1=new JLabel("PATIENT MANAGMENT SYSTEM");
	JLabel s2=new JLabel("OF INTERNATIONAL ISLAMIC UNIVERSITY.");
	JLabel s3=new JLabel("THIS SYSTEM IS DEVELOPED BY SYED ZOHAIB HAIDER.");
	   JPanel form_container = new JPanel();
		Font font=new Font("Roboto",Font.BOLD,23);
		 s.setFont(font);
		   s1.setFont(font);
		   s2.setFont(font);
		   s3.setFont(font);
	    form_container.setLayout(new GridBagLayout());
	   s.setFont(font);
		GridBagConstraints c=new GridBagConstraints();
		c.insets = new Insets(20, 20, 20, 20);
		 
		 
		    c.gridx=0;
		    c.gridy=0;
		   
		    s.setForeground(Color.green);
		    form_container.add(s,c);
		    c.gridx=0;
		    c.gridy=1;
		   
		    s1.setForeground(Color.green);
		    form_container.add(s1,c);
		    c.gridx=0;
		    c.gridy=2;
		   
		    s2.setForeground(Color.green);
		    form_container.add(s2,c);
		    c.gridx=0;
		    c.gridy=3;
		   
		    s3.setForeground(Color.green);
		    form_container.add(s3,c);
		    form_container.setBackground(Color.black);
		    frame.setVisible(true);
		    frame.add(form_container);
}
public void guest_toolbar()
{
	
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	
	  
	//icons
	
	  
	    SearchP=new ImageIcon("E:\\icons8-google-web-search-50.png");
	    Image i1=SearchP.getImage();
	    Image newicon1=i1.getScaledInstance(30,30,Image.SCALE_SMOOTH);
	    SearchP=new ImageIcon(newicon1);
	    Print=new ImageIcon("E:\\icons8-print-50.png");
	    Image i2=Print.getImage();
	    Image newicon2=i2.getScaledInstance(30,30,Image.SCALE_SMOOTH);
	    Print=new ImageIcon(newicon2);
	    
	  
	    search=new JButton("Search_patient",SearchP);

	    search.setVerticalTextPosition(JButton.BOTTOM);
	    search.setHorizontalTextPosition(JButton.CENTER);
	    search.setSize(50, 50);
	    print=new JButton("Print_record",Print);
	    
	    print.setVerticalTextPosition(JButton.BOTTOM);
	    print.setHorizontalTextPosition(JButton.CENTER);
	    print.setSize(50, 50);

	    toolBar.setBackground(Color.black);
	    toolBar.add(search);
	    search.setBackground(Color.green);
	    print.setBackground(Color.green);
	    toolBar.add(print);
	    toolBar.setSize(200,200);
	    toolBar.setBorder(BorderFactory.createLineBorder(Color.green, 2));
	    frame.add(toolBar,BorderLayout.NORTH);
		frame.getContentPane().setBackground(Color.black);
	    frame.setVisible(true);	
		title();
	    search.addActionListener(this);
	    print.addActionListener(this);
	    

}
public void actionPerformed(ActionEvent e) {
	// TODO Auto-generated method stub
	if(e.getSource()==PrintDoc)
	{
		Viewdoctors_detail s=new Viewdoctors_detail();
		s.showdetails();
	}
	else if(e.getSource()==Printdis)
	{
		Viewdiseases_details s=new Viewdiseases_details();
		s.showdetails();
	}
	else if(e.getSource()==Printpat)
	{
		ViewPatientdetails s=new ViewPatientdetails();
		s.showdetails();
	}
	else if(e.getSource()==Aboutus)
	{
		Aboutus s=new Aboutus();
		s.aboutus();
	}

	else if(e.getSource()==changepassword)
		{
		changepassword s=new changepassword();
		s.Login_form();
		}
	
	else if(e.getSource()==searchpatient_name)
	{
		searchpat_byname s=new searchpat_byname();
		s.search_patient();
	}
	else if(e.getSource()==searchpatient_age)
	{
		searchpat_byage s=new searchpat_byage();
		s.search_patient();
	}
	else if(e.getSource()==searchpatient_Id)
	{
		Searchpatient s=new Searchpatient();
		s.search_patient();
	}
	else if(e.getSource()==searchpatient_disease)
	{
		searchpatby_disease s=new searchpatby_disease();
		s.search_patient();
	}
	else if(e.getSource()==searchpatient_doctor)
	{
		Searchpat_bydoc s=new Searchpat_bydoc();
		s.search_patient();
	}

	else if(e.getSource()==searchdoctor_disspec)
		{
		Searchdoc_bydis s=new Searchdoc_bydis();
		s.search_doctor();
		}
	else if(e.getSource()==searchdoctor_name)
		{
		Searchdoc_byname s=new Searchdoc_byname();
		s.search_doctor();
		}
	else if(e.getSource()==search)
	{
		Searchpatient s=new Searchpatient();
		s.search_patient();
	}
	else if(e.getSource()==print)
	{
		Print_datainterface s=new Print_datainterface();
		s.showdatainterface();
	}
	else if(e.getSource()==close)
	{
		frame.dispose();
	}

}
}
