package patient_managment_systemgui;
import javax.swing.table.DefaultTableModel;

import com.toedter.calendar.JDateChooser;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;



public class Updatepatient implements ActionListener{
	JFrame frame = new JFrame();
	JLabel name;
	JLabel fathername;
	JLabel Sex;
	JLabel DOB;
	JLabel doctorname;
	JLabel disease_history;
	JLabel Prescription;
	JTextField namefield;
	JTextField fatherfield;
	JRadioButton male;
	JRadioButton female;
	ButtonGroup gende;    
	JComboBox<String> dnames;
	public JDateChooser calendar;
	Container container=frame.getContentPane();
	JLabel idJLabel;
	JTable table;
	JComboBox<String> ids;
	JButton UpdateButton=new JButton("Update");
	JButton CloseButton=new JButton("Close");
	JTextArea historyarea;
	JTextArea presarea;
	DefaultListModel<String> model = new DefaultListModel<String>();
	public void update_patient()
	{
		Object[][]rows= {};
		String []col= {"patient","name","fathername","Sex","DOB","diseasehistory","prescription","doctorid"};
		
		idJLabel=new JLabel("Select Patient id:");
		ids=new JComboBox<String>();
		
		DefaultTableModel d=new DefaultTableModel(rows,col);
		name=new JLabel("Patient_Name");
		fathername=new JLabel("Father_Name:");
		Sex=new JLabel("Patient_Sex:");
		DOB=new JLabel("Date-of-birth");
		doctorname=new JLabel("Doctor_Name:");
		disease_history=new JLabel("Disease_history:");
		Prescription=new JLabel("prescription :");
		
		//text fields
		namefield=new JTextField(25);
		fatherfield=new JTextField(25);
		
		//radio buttons
		male=new JRadioButton("male");
		female=new JRadioButton("female");
		gende=new ButtonGroup();
		gende.add(male);
		gende.add(female);

		calendar=new JDateChooser();
		
		
		
		
		dnames=new JComboBox<String>();
		//text area
		historyarea=new JTextArea();
		presarea=new JTextArea();
		historyarea.setBorder(BorderFactory.createLineBorder(Color.black, 2));
		presarea.setBorder(BorderFactory.createLineBorder(Color.black, 2));
		//layout
		JPanel rb=new JPanel();
		rb.add(male);
		rb.add(female);
	
		 JPanel form_container = new JPanel();
		
		 
		    form_container.setLayout(new GridBagLayout());
		   
			GridBagConstraints c=new GridBagConstraints();
	
		
		   
		    try {
		    	Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
		     String path="patient.accdb";
		    	String url="jdbc:ucanaccess://"+path;
		    	Connection connection=DriverManager.getConnection(url);
		    	 Statement ps=connection.createStatement();
		    	 String sql="select Patient_ID from Patients";
		    	  ResultSet resultSet=ps.executeQuery(sql);
		    	  while(resultSet.next()==true)
		    	  {
		    		  String disname=resultSet.getString("Patient_ID");
		    		  ids.addItem(disname);
		    	  }
		    
		    	  
		    } catch (Exception e) {
		    	// TODO: handle exception
		    }
		    	    
		
	
		
		 JPanel sePane=new JPanel();
		 sePane.add(ids);
		 c.insets=new Insets(20, 20, 20, 20);
		
		 
		    c.gridx=0;
		    c.gridy=0;
		    form_container.add(idJLabel);
		 
		    c.gridx=1;
		    c.gridy=0;
		
		 
		 
		    form_container.add(sePane,c);
		

		    c.gridx=0;
		    c.gridy=1;
		    name.setForeground(Color.green);
		    form_container.add(name,c);
		 
		    c.gridx=1;
		    c.gridy=1;
		    c.ipady=0;
		    c.ipadx=0;
		    namefield.setBorder(BorderFactory.createLineBorder(Color.green, 2));
		    namefield.setEnabled(false);
		    form_container.add(namefield,c);
		 
		    c.gridx=0;
		    c.gridy=2;
		    fathername.setForeground(Color.green);
		    form_container.add(fathername,c);
		    
		    c.gridx=1;
		    c.gridy=2;
		    c.ipady=0;
		    c.ipadx=0;
		    fatherfield.setBorder(BorderFactory.createLineBorder(Color.green, 2));
		    fatherfield.setEnabled(false);
		    form_container.add(fatherfield,c);
		    //sex
		    c.gridx=0;
		    c.gridy=3;
		    Sex.setForeground(Color.green);
		    form_container.add(Sex,c);
		   
		    c.gridx=1;
		    c.gridy=3;
		    rb.setBackground(Color.black);
		    male.setBackground(Color.green);
		    female.setBackground(Color.green);
		    male.setEnabled(false);
		    
		    female.setEnabled(false);
		    form_container.add(rb,c);

		    //DOB
		    c.gridx=0;
		    c.gridy=4;
		    DOB.setForeground(Color.green);
		    form_container.add(DOB,c);
		  
		    c.gridx=1;
		    c.gridy=4;
		    c.ipadx=59;
		    c.ipady=20;
		    calendar.setForeground(Color.green.darker());
		    calendar.setBorder(BorderFactory.createLineBorder(Color.green, 2));;
		    calendar.setEnabled(false);
		    form_container.add(calendar,c);
		    c.gridx=0;
		    c.gridy=5;
		    c.ipadx=0;
		    doctorname.setForeground(Color.green);
		    form_container.add(doctorname,c);
	try {
		Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
	 String path="patient.accdb";
		String url="jdbc:ucanaccess://"+path;
		Connection connection=DriverManager.getConnection(url);
		 Statement ps=connection.createStatement();
		 String sql="select Patient_Name from Patients";
		  ResultSet resultSet=ps.executeQuery(sql);
		  while(resultSet.next()==true)
		  {
			  String disname=resultSet.getString("Patient_Name");
			  dnames.addItem(disname);
		  }
	} catch (Exception e) {
		// TODO: handle exception
	}
		    
		    c.gridx=1;
		    c.gridy=5;
		    c.ipadx=59;
		    c.ipady=20;
		    dnames.setEnabled(false);
		    dnames.setBorder(BorderFactory.createLineBorder(Color.green, 2));;
		    dnames.setForeground(Color.green.darker());
		    form_container.add(dnames,c);

		    c.gridx=0;
		    c.gridy=6;
		    c.ipadx=0;
		    disease_history.setForeground(Color.green);
		    form_container.add(disease_history,c);
		    JScrollPane h=new JScrollPane(historyarea);
		    c.gridx=1;
		    c.gridy=6;
		    c.ipadx=300;
		    c.ipady=20;
		    h.setBorder(BorderFactory.createLineBorder(Color.green, 2));
		    form_container.add(h,c);
		    
		    c.gridx=0;
		    c.gridy=7;
		    c.ipadx=0;
		    Prescription.setForeground(Color.green);
		    form_container.add(Prescription,c);
		    JScrollPane ha=new JScrollPane(presarea);
		    c.gridx=1;
		    c.gridy=7;
		    c.ipadx=300;
		    c.ipady=20;
		    ha.setBorder(BorderFactory.createLineBorder(Color.green, 2));
		    form_container.add(ha,c);

		    c.gridx=0;
    	    c.gridy=8;
    	    c.ipadx=49;
    	    c.ipady=10;
    	    UpdateButton.setForeground(Color.black);
    	    UpdateButton.setBackground(Color.green);
    	    form_container.add(UpdateButton,c);
    	    c.gridx=1;
    	    c.gridy=8;
    	    c.ipadx=19;
    	    c.ipady=10;
    	    CloseButton.setForeground(Color.black);
    	    CloseButton.setBackground(Color.green);
    	    form_container.add(CloseButton,c);

		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(750,750);
		frame.setTitle("Update patient data");
		frame.setContentPane(form_container);
	    frame.getContentPane().setBackground(Color.black);
		frame.setVisible(true);	
		CloseButton.addActionListener(this);
        UpdateButton.addActionListener(this);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

		if(e.getSource()==UpdateButton)
		{
		String selected=(String) ids.getSelectedItem();
		try {
		Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
	    String path="patient.accdb";
		String url="jdbc:ucanaccess://"+path;
		Connection connection=DriverManager.getConnection(url);
		   
		
		    String sql="update Patients set Disease_History='"+historyarea.getText()+"',Prescription='"+presarea.getText()+"'where Patient_ID='"+selected+"'";
		   PreparedStatement ps=connection.prepareStatement(sql);
		   ps.execute();
		   JOptionPane.showMessageDialog(null, "Data updated sucessFully.");
		
			historyarea.setText("");
			presarea.setText("");
			connection.close();
	    } catch (Exception e1) {
	    	// TODO: handle exception
	    }
		}
		else if(e.getSource()==CloseButton)
		{
			frame.dispose();
		}
		}
	
		}
		
	
	

