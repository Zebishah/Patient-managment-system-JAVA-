package patient_managment_systemgui;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

import org.apache.commons.lang.ObjectUtils.Null;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.table.DefaultTableModel;



public class Searchpatient implements ActionListener{
	JFrame frame = new JFrame();
	Container container=frame.getContentPane();
	JLabel idJLabel;
	JTable table;
	JComboBox<String> ids;
	JButton SearchButton=new JButton("Search");
	JButton closeButton=new JButton("Close");

	DefaultListModel<String> model = new DefaultListModel<String>();
	public void search_patient()
	{
		Object[][]rows= {};
		String []col= {"Patient_Id","Patient_Name","Patient_Fathername","Patient_Sex","Patient_DOB","diseasehistory","prescription","Doctor_Id"};
		
		idJLabel=new JLabel("Select Patient id:");
		ids=new JComboBox<String>();
		
		DefaultTableModel d=new DefaultTableModel(rows,col);
		table=new JTable(d);
	
	
		        JPanel form_container = new JPanel();

		        form_container.setLayout(new GridBagLayout());
		   
	            GridBagConstraints c=new GridBagConstraints();
  
		    try {
		    	Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
		        String path="patient.accdb";
		    	String url="jdbc:ucanaccess://"+path;
		    	Connection connection=DriverManager.getConnection(url);
		    	Statement ps=connection.createStatement();
		    	String sql="select Patient_ID from Patients";
		    	ResultSet resultSet=ps.executeQuery(sql);
		    	  while(resultSet.next()==true)
		    	  {
		    		  String disname=resultSet.getString("Patient_ID");
		    		  ids.addItem(disname);
		    	  }
		    
		    	  
		    } catch (Exception e) {
		    	// TODO: handle exception
		    }
		    	    
		
		    ids.setBorder(BorderFactory.createLineBorder(Color.black, 2));
		
		    JScrollPane sePane=new JScrollPane(table);
		 
		    c.gridx=0;
		    c.gridy=0;
		    c.ipadx=10;
		    c.ipady=30;
		    idJLabel.setForeground(Color.green);
		    form_container.add(idJLabel,c);
		    
		    c.gridx=0;
		    c.gridy=1;
		    c.ipadx=50;
		    c.ipady=30;
		    ids.setBorder(BorderFactory.createLineBorder(Color.green, 2));
		    form_container.add(ids,c);
		    JTableHeader tableHeader=table.getTableHeader();
			tableHeader.setForeground(Color.black);
			tableHeader.setBackground(Color.green);
			sePane.setBackground(Color.green);
			table.setBackground(Color.green);
			table.setOpaque(false);
		    c.insets = new Insets(20, 20, 20, 20);
		    c.gridx=0;
		    c.gridy=3;
		    c.ipadx=700;
		    c.ipady=200;
		    sePane.setBorder(BorderFactory.createLineBorder(Color.green, 2));
		    form_container.add(sePane,c);
		    c.gridx=0;
    	    c.gridy=4;
    	    c.ipadx=19;
    	    c.ipady=10;
    	    SearchButton.setForeground(Color.black);
		    SearchButton.setBackground(Color.green);
    	    form_container.add(SearchButton,c);
    	    c.gridx=0;
    	    c.gridy=5;
    	    c.ipadx=19;
    	    c.ipady=10;
    	    closeButton.setForeground(Color.black);
		    closeButton.setBackground(Color.green);
    	    form_container.add(closeButton,c);
    	    
		
		    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		    frame.setSize(1370,770);
		    frame.setTitle("Search patient by ID");
		    frame.setContentPane(form_container);
		    frame.getContentPane().setBackground(Color.black);
		    frame.setVisible(true);	
		    closeButton.addActionListener(this);
            SearchButton.addActionListener(this);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		
		// TODO Auto-generated method stub
		if(e.getSource()==SearchButton)
		{
			if(ids.getSelectedItem().equals(""))
			{
				JOptionPane.showMessageDialog(null, "Field cant be empty enter Your credentials for Searching....");
			}
			else
			{
		String selected=(String) ids.getSelectedItem();
		try {
		Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
	    String path="patient.accdb";
		String url="jdbc:ucanaccess://"+path;
		Connection connection=DriverManager.getConnection(url);
		 Statement p=connection.createStatement();
		   String sql = "select * from Patients where Patient_ID='"+selected+"'";
		   ResultSet resultSet=p.executeQuery(sql);
		   if(resultSet.next()==true)
		   {
			   String sql1="SELECT Patient_ID,Patient_Name,Patient_Father_Name,Patient_Sex,Patient_DOB,Disease_History,Prescription,Doctor_Id FROM Patients WHERE Patient_ID='"+selected+"'";
			   PreparedStatement ps=connection.prepareStatement(sql1);
			   ResultSet rs=ps.executeQuery();
			 
			table.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(rs));
			
		     

		   }
		   else {
			   {
				   JOptionPane.showMessageDialog(null, "Data not exsisted.");
				   ids.setSelectedItem("");
			   }
		}
		
	    } catch (Exception e1) {
	    	// TODO: handle exception
	    }
			}
		}
		else if(e.getSource()==closeButton)
		{
			frame.dispose();
		}
		}
		
	}
