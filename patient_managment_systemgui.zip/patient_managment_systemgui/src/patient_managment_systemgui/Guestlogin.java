package patient_managment_systemgui;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

public class Guestlogin implements ActionListener{
	JFrame frame = new JFrame();
	JLabel user_name=new JLabel("Username:");
	Font f=new Font("Arial",Font.BOLD,30);
	Font fa=new Font("Arial",Font.BOLD,30);
    JTextField userfield=new JTextField(22);
    
    JLabel pass_word=new JLabel("Password:");
   
   
    JPasswordField passfield=new JPasswordField(22);
  
    JButton loginButton=new JButton("Login");
    JButton closeButton=new JButton("close");
public void Login_form()
{

			// JPanel = a GUI component that functions as a container to hold other components
		JLabel title=new JLabel("Login-Form");
		Font f=new Font("Arial",Font.BOLD,20);
	title.setFont(f);
		
	JPanel titlecontainer = new JPanel();

	titlecontainer.setBounds(280, 100, 150, 40);
	titlecontainer.setLayout(new FlowLayout(FlowLayout.CENTER));
	titlecontainer.add(title);
	//credentials
	
    user_name.setFont(f);
    
    loginButton.setFont(f);
    
    closeButton.setFont(f);
    
    pass_word.setFont(f);
   
    
  
    JButton loginButton=new JButton("Login");
    loginButton.setFont(f);
    //end
	
    JPanel form_container = new JPanel();
    form_container.setLayout(new GridBagLayout());
	GridBagConstraints c=new GridBagConstraints();
	
    c.insets=new Insets(20,20,20,20);
    c.gridx=1;
    c.gridy=0;
    title.setForeground(Color.green);
    form_container.add(title,c);
    c.gridx=0;
    c.gridy=1;
    user_name.setForeground(Color.green);
    form_container.add(user_name,c);
  
    c.gridx=1;
    c.gridy=1;
    c.ipady=10;
    userfield.setBorder(BorderFactory.createLineBorder(Color.green, 2));
    form_container.add(userfield,c);
    
    c.gridx=0;
    c.gridy=2;
    pass_word.setForeground(Color.green);
    form_container.add(pass_word,c);
    
    c.gridx=1;
    c.gridy=2;
    passfield.setBorder(BorderFactory.createLineBorder(Color.green, 2));
    form_container.add(passfield,c);
    
    c.gridx=1;
    c.gridy=5;
    c.ipadx=47;
    loginButton.setForeground(Color.black);
    loginButton.setBackground(Color.green);
    form_container.add(loginButton,c);
    c.gridx=1;
    c.gridy=6;
    c.ipadx=17;
    closeButton.setForeground(Color.black);
    closeButton.setBackground(Color.green);
    form_container.add(closeButton,c);
	form_container.setBounds(50, 150, 600, 300);
	
    
			
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			
			frame.setSize(750,750);
			frame.setVisible(true);	
		frame.setTitle("Login-Form");
			  frame.setContentPane(form_container);
			   
				frame.getContentPane().setBackground(Color.black);
		    loginButton.addActionListener(this);
		    closeButton.addActionListener(this);
		    
		
		   
		    
		

}
@Override
public void actionPerformed(ActionEvent e) {
	// TODO Auto-generated method stub
	if(e.getSource()==loginButton)
	{
	if(userfield.getText().equals("")||pass_word.getText().equals(""))
	{
		JOptionPane.showMessageDialog(null, "Text Fields cant be empty enter Your credentials for login....");
	}
	else
	{
		
	try {
		
			
		
	Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
    String path="patient.accdb";
	String url="jdbc:ucanaccess://"+path;
	Connection connection=DriverManager.getConnection(url);
	String sql="select * from form_details where username='"+userfield.getText()+"' and password='"+passfield.getText()+"'";
	PreparedStatement ps=connection.prepareStatement(sql);
	ResultSet result=ps.executeQuery();
	if(result.next())
	{
		
		JOptionPane.showMessageDialog(null, "Login sucessFully.");
		frame.dispose();
		Guestgui a=new Guestgui();
		a.guestMenu_bar();
		a.guest_toolbar();
	}
	else {
	
		JOptionPane.showMessageDialog(null, "Login denied.");
		userfield.setText("");
		passfield.setText("");
	}

	} catch (Exception e2) {
		// TODO: handle exception
	}
	}
	

	}
	else if(e.getSource()==closeButton) {
		frame.dispose();
	}
}
}
