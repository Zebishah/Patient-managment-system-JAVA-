package patient_managment_systemgui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class startinginterface implements ActionListener {
	JFrame sframe= new JFrame();
	
	ImageIcon addp ;
	JLabel label;
	JPanel panel;
	JButton admin=new JButton();
	JButton guest=new JButton();
	Font f=new Font("Arial",Font.BOLD,23);
	Font f2=new Font("Arial",Font.BOLD,24);
	JLabel title;
	JButton closeButton=new JButton("Close");
	public void Startinginterface()
	{

		admin.setText("Admin");
		admin.setFont(f);
		guest.setText("Guest");
		guest.setFont(f);
		title=new JLabel("Which Type of User u are:");
		try {
	
	    label=new JLabel();
	    addp=new ImageIcon("E://icons8-user-64.png"); 
	    label.setVerticalTextPosition(JButton.BOTTOM);
	    label.setHorizontalTextPosition(JButton.CENTER);
        label.setIcon(addp);
        title.setFont(f2);
		label.setHorizontalTextPosition(JLabel.CENTER);
		label.setVerticalTextPosition(JLabel.BOTTOM);
		} catch (Exception e) {
			// TODO: handle exception
		}
		JPanel sJPanel=new JPanel();
		sJPanel.add(label);
		sJPanel.setPreferredSize(new Dimension(100,100));
		 JPanel form_container = new JPanel();
 	    form_container.setLayout(new GridBagLayout());
 		GridBagConstraints c=new GridBagConstraints();
 		
 		
 		c.insets=new Insets(20,20,20,20);
 		
 	    
 		c.gridx=1;
 	    c.gridy=0;
 	    title.setForeground(Color.green);
 	    form_container.add(title,c);
 	    
	    c.gridx=1;
	    c.gridy=1;
	    c.ipadx=84;
	    c.ipady=14;
	    admin.setBackground(Color.green);
	    admin.setForeground(Color.black);
	    form_container.add(admin,c);
	    
	    c.gridx=1;
	    c.gridy=2;
	    c.ipadx=84;
	    c.ipady=14;
	    guest.setBackground(Color.green);
	    guest.setForeground(Color.black);
	    form_container.add(guest,c);
	  
	  
	    c.gridx=1;
	    c.gridy=3;
	    c.ipadx=20;
	    c.ipady=14;
	   
	    closeButton.setBackground(Color.green);
	    closeButton.setForeground(Color.black);
	    form_container.add(closeButton,c);
	  
		sframe.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		sframe.setSize(740, 650);
	
		sframe.setLocation(100,50);
		sframe.setTitle("Show data interface");
	    sframe.setContentPane(form_container);
		sframe.getContentPane().setBackground(Color.black);
		sframe.setVisible(true);
 		
		admin.addActionListener(this);
		guest.addActionListener(this);
	
		closeButton.addActionListener(this);
	}
	public void actionPerformed(ActionEvent e)
	{
		 if(e.getSource()==admin)
		 {
		
		Login form=new Login();
		form.Login_form();
		 }
		 else if(e.getSource()==guest)
		 {
			Guestlogin g=new Guestlogin();
			g.Login_form();
		 }
		else if(e.getSource()==closeButton)
		{
			sframe.dispose();
		}

	}
}
