package patient_managment_systemgui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.MenuBar;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.security.PublicKey;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;

public class Administratorgui implements ActionListener{
	

	JFrame frame = new JFrame();
	JLabel s=new JLabel("WELCOME TO OUR");
	JLabel s1=new JLabel("PATIENT MANAGMENT SYSTEM");
	JLabel s2=new JLabel("OF INTERNATIONAL ISLAMIC UNIVERSITY.");
	JLabel s3=new JLabel("THIS SYSTEM IS DEVELOPED BY SYED ZOHAIB HAIDER.");
	JButton close=new JButton("close");
    JMenuBar menuBar;
    JMenu Managerecord;
    JMenu Searchrecord;
    JMenu Help;
    JMenu Updaterecordsub;
    JMenuItem addpatient;
    JMenuItem adddoctor;
    JMenuItem addDisease;
    JMenuItem deletepatient;
   
    JMenuItem updatepatient;
    JMenuItem updatedoctor;
    JMenuItem searchpatient_name;
    JMenuItem searchpatient_Id;
    JMenuItem searchpatient_age;
    JMenuItem searchpatient_disease;
    JMenuItem searchpatient_doctor;
    JMenuItem searchdoctor_name;
    JMenuItem searchdoctor_disspec;
    JMenuItem Aboutus;
    JMenuItem changepassword;
    
    JToolBar toolBar=new JToolBar();
    ImageIcon addP;
    ImageIcon Add_do;
    ImageIcon SearchP;
    ImageIcon Print;
    JButton addp;
    JButton addD;
    JButton search;
    JButton print;
   
public void AdminMenu_bar()
{

			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.setTitle("Admin");
			frame.setSize(1370,770);
			
			
			
		
			Managerecord=new JMenu("Manage record");
			 Managerecord.setForeground(Color.green);
			 Managerecord.setBackground(Color.black);
			Searchrecord=new JMenu("Search record");
			Searchrecord.setForeground(Color.green);
			Searchrecord.setBackground(Color.black);
			Help=new JMenu("Help");
			Help.setForeground(Color.green);
			Searchrecord.setBackground(Color.black);
			Updaterecordsub=new JMenu("Update_record >");
			Updaterecordsub.setForeground(Color.green);
			  Updaterecordsub.setBackground(Color.black);
			Searchrecord.setBackground(Color.black);
			
			
			     addpatient=new JMenuItem("Add_patient_record");
			     addpatient.setForeground(Color.green);
			     addpatient.setBackground(Color.black);
			     adddoctor=new JMenuItem("Add_doctor_record ");
			     adddoctor.setForeground(Color.green);
			     adddoctor.setBackground(Color.black);
			     addDisease=new JMenuItem("Add_new_Disease");
			     addDisease.setForeground(Color.green);
			     addDisease.setBackground(Color.black);
			     deletepatient=new JMenuItem("Delete_patient_record");
			     deletepatient.setForeground(Color.green);
			     deletepatient.setBackground(Color.black);
			     updatepatient=new JMenuItem("update_patient_record");
			     updatepatient.setForeground(Color.green);
			     updatepatient.setBackground(Color.black);
			     updatedoctor=new JMenuItem("Update_Doctor_record");
			     updatedoctor.setForeground(Color.green);
			     updatedoctor.setBackground(Color.black);
			     searchpatient_name=new JMenuItem("Search_patientbyname");
			     searchpatient_name.setForeground(Color.green);
			     searchpatient_name.setBackground(Color.black);
			     searchpatient_Id=new JMenuItem("Search_patientbyid");
			     searchpatient_Id.setForeground(Color.green);
			     searchpatient_Id.setBackground(Color.black);
			     searchpatient_age=new JMenuItem("Search_patientbyage");
			     searchpatient_age.setForeground(Color.green);
			     searchpatient_age.setBackground(Color.black);
			     searchpatient_disease=new JMenuItem("Search_patientbydisease");
			     searchpatient_disease.setForeground(Color.green);
			     searchpatient_disease.setBackground(Color.black);
			     searchpatient_doctor=new JMenuItem("Search_patientbydoctor");
			     searchpatient_doctor.setForeground(Color.green);
			     searchpatient_doctor.setBackground(Color.black);
			     searchdoctor_name=new JMenuItem("Search_doctorbyname");
			     searchdoctor_name.setForeground(Color.green);
			     searchdoctor_name.setBackground(Color.black);
			     searchdoctor_disspec=new JMenuItem("Search_doctorbyspec");
			     searchdoctor_disspec.setForeground(Color.green);
			     searchdoctor_disspec.setBackground(Color.black);
			     Aboutus=new JMenuItem("About us");
			     Aboutus.setForeground(Color.green);
			     Aboutus.setBackground(Color.black);
			    
			   
			     changepassword=new JMenuItem("changepassword");
			     changepassword.setForeground(Color.green);
			     changepassword.setBackground(Color.black);
			     
			 	menuBar=new JMenuBar();
			 	menuBar.setPreferredSize(new Dimension(100,30));
			 	menuBar.setBorder(BorderFactory.createLineBorder(Color.green, 2));
				frame.setJMenuBar(menuBar);
			     
			     menuBar.add(Managerecord);
			     menuBar.add(Searchrecord);
			     menuBar.add(Help);
			     
			     
			     Managerecord.add(addpatient);
			     Managerecord.add(adddoctor);
			     Managerecord.add(addDisease);
			     Managerecord.add(deletepatient);
			     Managerecord.add(Updaterecordsub);
			     Updaterecordsub.add(updatepatient);
			     Updaterecordsub.add(updatedoctor);
			     Searchrecord.add(searchpatient_name);
			     Searchrecord.add(searchpatient_Id);
			     Searchrecord.add(searchpatient_age);
			     Searchrecord.add(searchpatient_disease);
			     Searchrecord.add(searchpatient_doctor);
			     Searchrecord.add(searchdoctor_name);
			     Searchrecord.add(searchdoctor_disspec);
			     Help.add(Aboutus);
			     Help.add(changepassword);
			     
			     
			     frame.setVisible(true);	
			     JPanel form_container = new JPanel();
				    
					form_container.setBackground(Color.black);
					
					
					  
					    		
					    form_container.add(close);
		   
		addDisease.addActionListener(this);
		addpatient.addActionListener(this);
		adddoctor.addActionListener(this);
		deletepatient.addActionListener(this);
		Updaterecordsub.addActionListener(this);
		updatedoctor.addActionListener(this);
		updatepatient.addActionListener(this);
		searchpatient_age.addActionListener(this);
		searchpatient_name.addActionListener(this);
		searchpatient_Id.addActionListener(this);
		searchpatient_disease.addActionListener(this);
		searchpatient_doctor.addActionListener(this);
		searchdoctor_name.addActionListener(this);
		searchdoctor_disspec.addActionListener(this);
		Aboutus.addActionListener(this);
		changepassword.addActionListener(this);
		close.addActionListener(this);
		menuBar.setBackground(Color.black);
	    frame.add(form_container,BorderLayout.PAGE_END);
	
}	
public void Admin_toolbar()
{
	
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	frame.setTitle("Admin");
	frame.setSize(1370,770);
	 close.setForeground(Color.black);
	    close.setBackground(Color.green);
	  toolBar.setBackground(Color.black);
	//icons
	
	    addP=new ImageIcon("E:\\icons8-add-new-50.png");
	    
	    Add_do=new ImageIcon("E:\\icons8-user-48.png");
	    Image i4=Add_do.getImage();
	    Image newicon4=i4.getScaledInstance(30,30,Image.SCALE_SMOOTH);
	    Add_do=new ImageIcon(newicon4);
	    SearchP=new ImageIcon("E:\\icons8-google-web-search-50.png");
	    Image i1=SearchP.getImage();
	    Image newicon1=i1.getScaledInstance(30,30,Image.SCALE_SMOOTH);
	    SearchP=new ImageIcon(newicon1);
	    Print=new ImageIcon("E:\\icons8-print-50.png");
	    Image i2=Print.getImage();
	    Image newicon2=i2.getScaledInstance(30,30,Image.SCALE_SMOOTH);
	    Print=new ImageIcon(newicon2);
	    
	    Image i=addP.getImage();
	    Image newicon=i.getScaledInstance(30,30,Image.SCALE_SMOOTH);
	    addP=new ImageIcon(newicon);
	    //buttons
	    addp=new JButton("Add_patient",addP);
	    addp.setForeground(Color.black);
	    addp.setBackground(Color.green);
	    addp.setVerticalTextPosition(JButton.BOTTOM);
	    addp.setHorizontalTextPosition(JButton.CENTER);
	    addp.setSize(50, 50);
	    addD=new JButton("Add_Doctor",Add_do);
	    addD.setForeground(Color.black);
	    addD.setBackground(Color.green);
	    addD.setVerticalTextPosition(JButton.BOTTOM);
	    addD.setHorizontalTextPosition(JButton.CENTER);
	    addD.setSize(50, 50);
	    search=new JButton("Search_patient",SearchP);
	    search.setForeground(Color.black);
	    search.setBackground(Color.green);
	    search.setVerticalTextPosition(JButton.BOTTOM);
	    search.setHorizontalTextPosition(JButton.CENTER);
	    search.setSize(50, 50);
	    print=new JButton("Print_record",Print);
	    print.setForeground(Color.black);
	    print.setBackground(Color.green);
	    print.setVerticalTextPosition(JButton.BOTTOM);
	    print.setHorizontalTextPosition(JButton.CENTER);
	    print.setSize(50, 50);

	    toolBar.add(addp);
	    toolBar.add(addD);
	    toolBar.add(search);
	    toolBar.add(print);
	    toolBar.setSize(200,200);
	    toolBar.setBorder(BorderFactory.createLineBorder(Color.green, 2));
	 
		    title();
	    frame.add(toolBar,BorderLayout.NORTH);
	   
		frame.getContentPane().setBackground(Color.black);
	   
	    frame.setVisible(true);	
	    addp.addActionListener(this);
	    addD.addActionListener(this);
	    search.addActionListener(this);
	    print.addActionListener(this);
	    
	 
}
public void title()
{
	   JPanel form_container = new JPanel();
		Font font=new Font("Roboto",Font.BOLD,23);
		 
	    form_container.setLayout(new GridBagLayout());
	   s.setFont(font);
	   s1.setFont(font);
	   s2.setFont(font);
	   s3.setFont(font);
		GridBagConstraints c=new GridBagConstraints();
		c.insets = new Insets(20, 20, 20, 20);
		 
		 
		    c.gridx=0;
		    c.gridy=0;
		   
		    s.setForeground(Color.green);
		    form_container.add(s,c);
		    c.gridx=0;
		    c.gridy=1;
		   
		    s1.setForeground(Color.green);
		    form_container.add(s1,c);
		    c.gridx=0;
		    c.gridy=2;
		   
		    s2.setForeground(Color.green);
		    form_container.add(s2,c);
		    c.gridx=0;
		    c.gridy=3;
		   
		    s3.setForeground(Color.green);
		    form_container.add(s3,c);
		    form_container.setBackground(Color.black);
		    frame.setVisible(true);
		    frame.add(form_container);
}
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==addDisease)
		{
			Adddisease s=new Adddisease();
			s.Add_disease();
		}
		else if(e.getSource()==addpatient)
		{
			addpatient s=new addpatient();
			s.addpatient();
		}
		else if(e.getSource()==adddoctor)
		{
			Adddoctor s=new Adddoctor();
			s.Add_doctor();
		}
		else if(e.getSource()==deletepatient)
		{
			Deletepat_record s=new Deletepat_record();
			s.delete_patient();
		}
	
		else if(e.getSource()==updatepatient)
			{
			Updatepatient s=new Updatepatient();
			s.update_patient();
			}
		else if(e.getSource()==updatedoctor)
			{
			updatedoctor s=new updatedoctor();
			s.update_doctor();
			}
	
		else if(e.getSource()==searchpatient_name)
		{
			searchpat_byname s=new searchpat_byname();
			s.search_patient();
		}
		if(e.getSource()==searchpatient_age)
		{
			searchpat_byage s=new searchpat_byage();
			s.search_patient();
		}
		else if(e.getSource()==searchpatient_Id)
		{
			Searchpatient s=new Searchpatient();
			s.search_patient();
		}
		else if(e.getSource()==searchpatient_disease)
		{
			searchpatby_disease s=new searchpatby_disease();
			s.search_patient();
		}
		else if(e.getSource()==searchpatient_doctor)
		{
			Searchpat_bydoc s=new Searchpat_bydoc();
			s.search_patient();
		}
	
		else if(e.getSource()==searchdoctor_disspec)
			{
			Searchdoc_bydis s=new Searchdoc_bydis();
			s.search_doctor();
			}
		else if(e.getSource()==searchdoctor_name)
			{
			Searchdoc_byname s=new Searchdoc_byname();
			s.search_doctor();
			}
		else if(e.getSource()==addp)
		{
			addpatient s=new addpatient();
			s.addpatient();
		}
		else if(e.getSource()==addD)
		{
			Adddoctor s=new Adddoctor();
			s.Add_doctor();
		}
		else if(e.getSource()==search)
		{
			Searchpatient s=new Searchpatient();
			s.search_patient();
		}
		else if(e.getSource()==print)
		{
			Print_datainterface s=new Print_datainterface();
			s.showdatainterface();
		}
		else if(e.getSource()==Aboutus)
		{
		Aboutus s=new Aboutus();
		s.aboutus();
		}
		else if(e.getSource()==changepassword)
		{
		changepassword s=new changepassword();
		s.Login_form();
		}
		else if(e.getSource()==close)
		{
			frame.dispose();
		}
	
	}
}
