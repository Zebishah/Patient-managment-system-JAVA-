package patient_managment_systemgui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class Aboutus implements ActionListener{
	JFrame frame = new JFrame();
	JButton close=new JButton("Close");
	
public void aboutus()
{
	
		JLabel s=new JLabel("WELCOME TO OUR");
		JLabel s1=new JLabel("PATIENT MANAGMENT SYSTEM");
		JLabel s2=new JLabel("OF INTERNATIONAL ISLAMIC UNIVERSITY.");
		JLabel s3=new JLabel("THIS SYSTEM IS DEVELOPED BY SYED ZOHAIB HAIDER(4122-F20).");
		JLabel s4=new JLabel("By using this system our university medical section will easily manage");
		JLabel s5=new JLabel("Doctors and patients data and also manage the records of all patients that");
		JLabel s6=new JLabel("area admit in medical section and all the doctors data that are in medical section.");
		
		   JPanel form_container = new JPanel();
			Font font=new Font("Roboto",Font.BOLD,23);
			 s.setFont(font);
			   s1.setFont(font);
			   s2.setFont(font);
			   s3.setFont(font);
			   s4.setFont(font);
			   s5.setFont(font);
			   s6.setFont(font);
		    form_container.setLayout(new GridBagLayout());
		   s.setFont(font);
			GridBagConstraints c=new GridBagConstraints();
			c.insets = new Insets(20, 20, 20, 20);
			 
			 
			    c.gridx=0;
			    c.gridy=0;
			   
			    s.setForeground(Color.green);
			    form_container.add(s,c);
			    c.gridx=0;
			    c.gridy=1;
			   
			    s1.setForeground(Color.green);
			    form_container.add(s1,c);
			    c.gridx=0;
			    c.gridy=2;
			   
			    s2.setForeground(Color.green);
			    form_container.add(s2,c);
			    c.gridx=0;
			    c.gridy=3;
			   
			    s3.setForeground(Color.green);
			    form_container.add(s3,c);
			    c.gridx=0;
			    c.gridy=4;
			   
			    s4.setForeground(Color.green);
			    form_container.add(s4,c);
			    c.gridx=0;
			    c.gridy=5;
			   
			    s5.setForeground(Color.green);
			    form_container.add(s5,c);
			    c.gridx=0;
			    c.gridy=6;
			   
			    s6.setForeground(Color.green);
			    form_container.add(s6,c);
			    c.gridx=0;
			    c.gridy=7;
			    c.ipady=20;
			    c.ipadx=100;
			   close.setFont(font);
			    close.setForeground(Color.black);
			    close.setBackground(Color.green);
			    form_container.add(close,c);
			    form_container.setBackground(Color.black);
		  

	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	frame.add(form_container);
	frame.setSize(1300,700);
	frame.setVisible(true);	
	frame.setTitle("About Us-(4122)");
	close.addActionListener(this);
}

@Override
public void actionPerformed(ActionEvent e) {
	// TODO Auto-generated method stub
	frame.dispose();
}
}
