package patient_managment_systemgui;

import java.awt.Color;
import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

public class searchpatby_disease implements ActionListener{
	JFrame frame = new JFrame();
	Container container=frame.getContentPane();
	JLabel idJLabel;
	JTable table;
	
	JButton SearchButton=new JButton("Search");
	JButton closeButton=new JButton("Close");
	JTextField ids;
	DefaultListModel<String> model = new DefaultListModel<String>();
	public void search_patient()
	{
		Object[][]rows= {};
		String []col= {"Patient_Id","Patient_Name","Patient_Fathername","Patient_Sex","Patient_DOB","diseasehistory","prescription","Doctor_Id"};
		idJLabel=new JLabel("Enter Disease name:");
		ids=new JTextField();
		DefaultTableModel d=new DefaultTableModel(rows,col);
		table=new JTable(d);
		
		JPanel form_container = new JPanel();

		form_container.setLayout(new GridBagLayout());
	
			GridBagConstraints c=new GridBagConstraints();
			
		    ids.setBorder(BorderFactory.createLineBorder(Color.black, 2));
		    
		    JScrollPane sePane=new JScrollPane(table);
		    c.gridx=0;
		    c.gridy=0;
		    idJLabel.setForeground(Color.green);
		    form_container.add(idJLabel,c);
		    
		    c.gridx=0;
		    c.gridy=1;
		    c.ipadx=200;
		    c.ipady=10;
		    ids.setBorder(BorderFactory.createLineBorder(Color.green, 2));
		    form_container.add(ids,c);
		    
		    JTableHeader tableHeader=table.getTableHeader();
			tableHeader.setForeground(Color.black);
			frame.setTitle("Search doctor by disease specilization-(Zohaib-4122)");
			tableHeader.setBackground(Color.green);
			sePane.setBackground(Color.green);
			table.setBackground(Color.green);
			table.setOpaque(false);
			
			c.insets = new Insets(20, 20, 20, 20);
		    c.gridx=0;
		    c.gridy=2;
		    c.ipadx=700;
		    c.ipady=200;
		    sePane.setBorder(BorderFactory.createLineBorder(Color.green, 2));
		    frame.setTitle("Search doctor by disease specilization-(Zohaib-4122)");
		    
		    form_container.add(sePane,c);
		    c.gridx=0;
    	    c.gridy=4;
    	    c.ipadx=19;
    	    c.ipady=10;
    	    SearchButton.setForeground(Color.black);
		    SearchButton.setBackground(Color.green);
    	    form_container.add(SearchButton,c);
    	    c.gridx=0;
    	    c.gridy=5;
    	    c.ipadx=19;
    	    c.ipady=10;
    	    closeButton.setForeground(Color.black);
		    closeButton.setBackground(Color.green);
    	    form_container.add(closeButton,c);
    	    
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(1370,770);
		frame.setContentPane(form_container);
		frame.getContentPane().setBackground(Color.black);
		frame.setVisible(true);	
		closeButton.addActionListener(this);
        SearchButton.addActionListener(this);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==SearchButton)
		{
			String selected=(String)ids.getText();
			if(selected.equals(""))
			{
				JOptionPane.showMessageDialog(null, "Field cant be empty enter Your credentials for Searching....");
			}
			else
			{
		
		 
	
		try {
		Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
	    String path="patient.accdb";
		String url="jdbc:ucanaccess://"+path;
		Connection connection=DriverManager.getConnection(url);
		Statement p=connection.createStatement();
		 String sql1 = "select * from Patients where Disease_History='"+selected+"'";
		   ResultSet resultSet=p.executeQuery(sql1);
		   if(resultSet.next()==true)
		   {
		  String sql="SELECT Patient_ID,Patient_Name,Patient_Father_Name,Patient_Sex,Patient_DOB,Disease_History,Prescription,Doctor_Id FROM Patients WHERE Disease_History='"+selected+"'";
		   PreparedStatement ps=connection.prepareStatement(sql);
		   ResultSet rs=ps.executeQuery();
		   
		table.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(rs));
		   }
		   else 
		   {
			   JOptionPane.showMessageDialog(null, "Data not exsisted.");
			   ids.setText("");
		   }
	    } catch (Exception e1) {
	    	// TODO: handle exception
	    }
			}
		}
		else if(e.getSource()==closeButton)
		{
			frame.dispose();
		}
		}
}
